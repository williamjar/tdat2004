public class MathServices {

    enum Operations {
        ADD,
        SUBTRACT
    }

    public static int addNumbers(int a, int b){
        return a+b;
    }

    public static int subtractNumbers(int a, int b){
        return a-b;
    }
}